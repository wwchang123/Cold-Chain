#ifndef _NTC_H_
#define _NTC_H_


#include "stm32f10x.h"
float ADC_Temperature(u16 value);

#endif

