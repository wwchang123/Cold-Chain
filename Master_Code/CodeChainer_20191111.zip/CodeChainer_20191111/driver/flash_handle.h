#ifndef _FLASH_HANDLE_H
#define _FLASH_HANDLE_H

#include "stm32f10x.h"


void GetSeri_Num(void);
void SaveNewIP(void);
void SaveSensor(u8 length);
void GetIP_Com(void);
void GetSenior_num(void);

#endif

