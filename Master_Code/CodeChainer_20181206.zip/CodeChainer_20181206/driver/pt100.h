#ifndef _PT100_H
#define _PT100_H

#include "adc.h"
float get_temp(u8 ch);


#endif
