#ifndef _ID_H
#define _ID_H


#include "stm32f10x.h"

void get_eight_id(void);

#endif
