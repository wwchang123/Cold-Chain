#ifndef _GETBELT_H
#define _GETBELT_H

#include "stm32f10x.h"

void sendbelt_data(void);

#endif
