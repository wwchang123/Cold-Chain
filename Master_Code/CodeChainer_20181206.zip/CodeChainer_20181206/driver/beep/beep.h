#ifndef _BEEP_H
#define _BEEP_H

#include "stm32f10x.h"

void BeepIO_Config(void);
void poweron_beep(void);
void Flash_Fault(void);
void Flash_Seri(void);

#endif

